import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from venues.models import Venue
from .serializers import RecommendedVenueSerializer
from .recommendation_engine import VenueRecommender
from .models import UserVenueInteraction
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer  # Sentiment analysis

logger = logging.getLogger(__name__)

# Singleton instance of the recommender
recommender = VenueRecommender()


class VenueRecommendationsView(APIView):
    """
    API endpoint for retrieving similar venues based on a given venue ID.
    """
    permission_classes = []  # Public access

    def get(self, request, venue_id):
        try:
            logger.info(f"Recommendation request for venue_id: {venue_id}")

            # Validate venue
            try:
                venue = Venue.objects.get(pk=venue_id)
                logger.info(f"Found venue: {venue.name}")
            except Venue.DoesNotExist:
                return Response({"error": "Venue not found"}, status=status.HTTP_404_NOT_FOUND)

            # Record user interaction
            if request.user.is_authenticated:
                UserVenueInteraction.objects.create(
                    user=request.user,
                    venue=venue,
                    interaction_type='view'
                )

            # Get recommended venues from the recommendation engine
            recommended_venues = recommender.get_similar_venues(venue_id)
            if not recommended_venues:
                return Response([])

            # Filter valid Venue objects
            venue_ids = [v.id for v in recommended_venues if hasattr(v, 'id')]
            recommended_venues_qs = Venue.objects.filter(id__in=venue_ids)

            serializer = RecommendedVenueSerializer(recommended_venues_qs, many=True)
            return Response(serializer.data)

        except Exception as e:
            logger.error(f"Error in VenueRecommendationsView: {str(e)}")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PersonalizedRecommendationsView(APIView):
    """
    API endpoint for personalized venue recommendations for authenticated users.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            recommended_venues = recommender.get_personalized_recommendations(user=request.user)
            if not recommended_venues:
                return Response([])

            # Filter valid Venue objects
            venue_ids = [v.id for v in recommended_venues if hasattr(v, 'id')]
            recommended_venues_qs = Venue.objects.filter(id__in=venue_ids)

            serializer = RecommendedVenueSerializer(recommended_venues_qs, many=True)
            return Response(serializer.data)

        except Exception as e:
            logger.error(f"Error in PersonalizedRecommendationsView: {str(e)}")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
