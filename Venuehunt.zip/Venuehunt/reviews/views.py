from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from venues.models import Review, Venue
from bookings.models import Booking
from django.views import View

class VenueReviewsView(View):
    def get(self, request, venue_id):
        venue = get_object_or_404(Venue, id=venue_id)
        reviews = Review.objects.filter(venue=venue).order_by('-id')

        # Add sentiment labels for display
        for review in reviews:
            score = review.sentiment
            if score >= 0.05:
                review.sentiment_label = "Positive 😊"
            elif score <= -0.05:
                review.sentiment_label = "Negative 😞"
            else:
                review.sentiment_label = "Neutral 😐"
        return render(request, "reviews/venue_reviews.html", {
            "venue": venue,
            "reviews": reviews
        })


@login_required
def add_review(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    venue = booking.venue
    
    # Check if user is the organizer of this booking
    if request.user != booking.organizer:
        return redirect('bookings:booking_detail', pk=booking_id)
    
    # Check if review already exists for this booking
    existing_review = Review.objects.filter(booking=booking).first()
    if existing_review:
        return redirect('reviews:edit_review', review_id=existing_review.id)

    if request.method == "POST":
        comment = request.POST.get("comment")
        rating = request.POST.get("rating")

        Review.objects.create(
            venue=venue,
            reviewer=request.user,
            booking=booking,
            comment=comment,
            rating=rating
        )
        return redirect('bookings:booking_detail', pk=booking_id)

    # Render the review form for GET request
    from .forms import ReviewForm
    form = ReviewForm()
    return render(request, "reviews/review_form.html", {
        "form": form,
        "venue": venue,
        "booking": booking,
        "is_edit": False
    })


@login_required
def edit_review(request, review_id):
    review = get_object_or_404(Review, id=review_id)

    if request.user != review.reviewer:
        if review.booking:
            return redirect('bookings:booking_detail', pk=review.booking.id)
        return redirect('venues:venue_detail', pk=review.venue.id)

    if request.method == "POST":
        review.comment = request.POST.get("comment")
        review.rating = request.POST.get("rating")
        review.save()  # This will automatically recalculate sentiment
        
        if review.booking:
            return redirect('bookings:booking_detail', pk=review.booking.id)
        return redirect('venues:venue_detail', pk=review.venue.id)

    from .forms import ReviewForm
    form = ReviewForm(instance=review)
    return render(request, "reviews/review_form.html", {
        "form": form,
        "review": review,
        "venue": review.venue,
        "booking": review.booking,
        "is_edit": True
    })


@login_required
def delete_review(request, review_id):
    review = get_object_or_404(Review, id=review_id)

    if request.user != review.reviewer:
        if review.booking:
            return redirect('bookings:booking_detail', pk=review.booking.id)
        return redirect('venues:venue_detail', pk=review.venue.id)

    booking_id = review.booking.id if review.booking else None
    venue_id = review.venue.id
    review.delete()
    
    if booking_id:
        return redirect('bookings:booking_detail', pk=booking_id)
    return redirect('venues:venue_detail', pk=venue_id)
